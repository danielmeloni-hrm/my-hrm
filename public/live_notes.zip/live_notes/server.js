const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const cors = require("cors");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);

const io = new Server(server, {
  cors: { origin: "*" },
});

app.post("/update-code", (req, res) => {
  const { filePath, code, userId } = req.body;

  const fileName = path.basename(filePath || "lavora-qui.js");

  const payload = {
    fileName,
    fullPath: filePath,
    code,
  };

  if (userId) {
    io.to(userId).emit("code-update", payload);
  } else {
    io.emit("code-update", payload);
  }

  res.json({ ok: true, sent: payload });
});

io.on("connection", (socket) => {
  console.log("Client connesso:", socket.id);

  socket.on("join-room", (userId) => {
    if (!userId) return;
    socket.join(userId);
    console.log(`Socket ${socket.id} entrato nella room ${userId}`);
  });
});

server.listen(4000, () => {
  console.log("Server attivo su https://sublime-bridge-server.onrender.com");
});