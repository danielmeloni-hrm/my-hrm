const fs = require("fs");
const path = require("path");

// CONFIGURAZIONE
const NOTES_DIR = path.join(__dirname, "notes");
const SERVER_URL = "https://sublime-bridge-server.onrender.com/update-code";
const USER_ID = "user_tr1gpzh"; // Il tuo ID sessione

// Estensioni permesse
const allowedExtensions = [".js", ".jsx", ".ts", ".tsx", ".txt", ".md", ".json", ".css", ".html"];
const watchedFiles = new Set();

// Crea la cartella se non esiste
if (!fs.existsSync(NOTES_DIR)) {
  fs.mkdirSync(NOTES_DIR, { recursive: true });
}

/**
 * Funzione per inviare il file al server
 */
async function sendFile(fileName) {
  try {
    const fullPath = path.join(NOTES_DIR, fileName);
    if (!fs.existsSync(fullPath)) return;

    const stats = fs.statSync(fullPath);
    if (stats.isDirectory()) return; // Salta le sottocartelle

    const code = fs.readFileSync(fullPath, "utf8");

    const response = await fetch(SERVER_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ 
        filePath: fullPath, 
        code: code,
        userId: USER_ID 
      }),
    });

    if (response.ok) {
      console.log(`[SYNC OK] ${fileName}`);
    } else {
      console.error(`[ERRORE SERVER] ${fileName}: ${response.statusText}`);
    }
  } catch (error) {
    console.error(`[ERRORE INVIO] ${fileName}:`, error.message);
  }
}

/**
 * Registra un file per il monitoraggio continuo
 */
function watchFile(fileName) {
  const ext = path.extname(fileName);
  if (watchedFiles.has(fileName) || !allowedExtensions.includes(ext)) return;

  const fullPath = path.join(NOTES_DIR, fileName);
  watchedFiles.add(fileName);
  
  // Monitora i salvataggi (CTRL+S in Sublime)
  fs.watchFile(fullPath, { interval: 100 }, () => {
    console.log(`[MODIFICA] ${fileName}`);
    sendFile(fileName);
  });

  // Invio iniziale immediato
  sendFile(fileName);
}

/**
 * Scansione della cartella e avvio
 */
console.log(`-------------------------------------------`);
console.log(`🚀 Watcher attivo per sessione: ${USER_ID}`);
console.log(`📂 Cartella: ${NOTES_DIR}`);
console.log(`-------------------------------------------`);

// 1. Legge e invia tutti i file esistenti per creare i Tabs
const files = fs.readdirSync(NOTES_DIR);
if (files.length === 0) {
  console.log("La cartella è vuota. Crea un file in Sublime per iniziare.");
} else {
  console.log(`Sincronizzazione di ${files.length} file in corso...`);
  files.forEach(file => watchFile(file));
}

// 2. Rileva se aggiungi nuovi file nella cartella mentre il watcher corre
fs.watch(NOTES_DIR, (event, file) => {
  if (file && event === "rename") {
    const fullPath = path.join(NOTES_DIR, file);
    if (fs.existsSync(fullPath) && !watchedFiles.has(file)) {
      console.log(`[NUOVO TAB] ${file}`);
      watchFile(file);
    }
  }
});